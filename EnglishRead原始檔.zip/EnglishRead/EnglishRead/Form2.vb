﻿Imports System.IO

Public Class Form2
    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub ToolStripButton2_Click(sender As Object, e As EventArgs) Handles ToolStripButton2.Click
        Form3.Show()
        Me.Hide()
    End Sub

    Private Sub ToolStripButton3_Click(sender As Object, e As EventArgs) Handles ToolStripButton3.Click
        Form4.Show()
        Me.Hide()
    End Sub
    '/選擇題庫/
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim OpenFileDialog1 As OpenFileDialog = New OpenFileDialog
        OpenFileDialog1.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.Desktop
        OpenFileDialog1.Filter = "txt files (*.txt)|*.txt"
        OpenFileDialog1.Multiselect = False
        If OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Dim text As StreamReader = My.Computer.FileSystem.OpenTextFileReader(OpenFileDialog1.FileName)
            If text.ReadLine() = "EnglishReadUSE" Then
                If Integer.TryParse(text.ReadLine(), Nothing) = False Then
                    MsgBox("檔案資料型態錯誤(行數)", MsgBoxStyle.Critical, "System")
                    text.Close()
                    GoTo endsub
                End If
            Else
                MsgBox("檔案資料型態錯誤(EnglishReadUSE)", MsgBoxStyle.Critical, "System")
                text.Close()
                GoTo endsub
            End If
            TextBox1.Text = text.ReadToEnd
            Label4.Text = OpenFileDialog1.FileName
            '初始化
            TextBox1.Enabled = True
            TextBox2.Enabled = True
            TextBox3.Enabled = True
            TextBox2.Text = ""
            TextBox3.Text = ""
            TextBox2.Focus()
endsub:     text.Close()
        End If
    End Sub
    '/寫入題目/
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If Label4.Text = "" Then
            MsgBox("請選擇題庫或新增題庫", MsgBoxStyle.Information, "System")
            GoTo endsub
        ElseIf TextBox2.Text = "" Or TextBox3.Text = "" = True Then
            MsgBox("請你要的中英文都輸入", MsgBoxStyle.Information, "System")
            GoTo endsub
        End If
        If My.Computer.FileSystem.FileExists(Label4.Text) = False Then
            MsgBox("檔案不存在(或是檔名已被更改)，" & vbCrLf & "請重新選擇題庫", MsgBoxStyle.Critical, "System")
            GoTo endsub
        End If
        '讀取檔案
        Dim textRead As StreamReader = My.Computer.FileSystem.OpenTextFileReader(Label4.Text)
        Dim linetext As String
        Dim textline As Integer     '題數
        If textRead.ReadLine() = "EnglishReadUSE" Then
            linetext = textRead.ReadLine()
            If Integer.TryParse(linetext, textline) = False Then
                MsgBox("檔案資料型態錯誤(行數)", MsgBoxStyle.Critical, "System")
                textRead.Close()
                GoTo endsub
            End If
        Else
            MsgBox("檔案資料型態錯誤(EnglishReadUSE)", MsgBoxStyle.Critical, "System")
            textRead.Close()
            GoTo endsub
        End If
        '確認題目是否已存在
        Dim text(textline, 1) As String
        For i = 0 To textline - 1
            textRead.ReadLine()
            text(i, 0) = textRead.ReadLine() 'chinese textbox2
            text(i, 1) = textRead.ReadLine() 'english textbox3
            If text(i, 0) = TextBox2.Text And text(i, 1) = TextBox3.Text Then
                MsgBox("這題你有了，請換別的", MsgBoxStyle.Critical, "System")
                textRead.Close()
                GoTo endsub
            End If
            textRead.ReadLine()
        Next
        textRead.Close()
        My.Computer.FileSystem.DeleteFile(Label4.Text)
        '寫入題目
        Dim textWriter As StreamWriter = My.Computer.FileSystem.OpenTextFileWriter(Label4.Text, True)
        textWriter.WriteLine("EnglishReadUSE")  '題型判斷
        textWriter.WriteLine(textline + 1)  '題數判斷
        If TextBox1.Text <> "" Then
            textWriter.WriteLine(TextBox1.Text)
        End If
        textWriter.WriteLine(textline + 1 & vbCrLf & TextBox2.Text & vbCrLf & TextBox3.Text) '4行中上英下
        textWriter.Flush() : textWriter.Close()
        '重新寫入Textbox1
        Dim aftertext As StreamReader = My.Computer.FileSystem.OpenTextFileReader(Label4.Text)
        aftertext.ReadLine()
        aftertext.ReadLine()
        TextBox1.Text = aftertext.ReadToEnd
        aftertext.Close()
        '初始化
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox2.Focus()
endsub: End Sub
    '/刪除題目/
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If Label4.Text = "" Then
            MsgBox("請選擇題庫或新增題庫", MsgBoxStyle.Information, "System")
            GoTo endsub
        ElseIf TextBox2.Text = "" Or TextBox3.Text = "" = True Then
            MsgBox("把要刪除的中英文輸入上去", MsgBoxStyle.Information, "System")
            GoTo endsub
        End If
        If My.Computer.FileSystem.FileExists(Label4.Text) = False Then
            MsgBox("檔案不存在(或是檔名已被更改)，" & vbCrLf & "請重新選擇題庫", MsgBoxStyle.Critical, "System")
            GoTo endsub
        End If
        '讀取檔案-----
        Dim textRead As StreamReader = My.Computer.FileSystem.OpenTextFileReader(Label4.Text)
        Dim linetext As String
        Dim textline As Integer         '題數
        If textRead.ReadLine() = "EnglishReadUSE" Then
            linetext = textRead.ReadLine()
            If Integer.TryParse(linetext, textline) = False Then
                MsgBox("檔案資料型態錯誤(行數)", MsgBoxStyle.Critical, "System")
                textRead.Close()
                GoTo endsub
            End If
        Else
            MsgBox("檔案資料型態錯誤(EnglishReadUSE)", MsgBoxStyle.Critical, "System")
            textRead.Close()
            GoTo endsub
        End If
        If MsgBox("是否確定刪除題目", MsgBoxStyle.OkCancel, "System") = 2 Then
            GoTo endsub
        End If
        If textline = 0 Then
            MsgBox("你檔案裡沒題目...", MsgBoxStyle.Critical, "System")
            GoTo endsub
        End If
        '找尋題目-----
        Dim text(textline, 1) As String
        Dim textfind As Boolean = False
        Dim textnum As Integer  '題目位置
        For i = 0 To textline - 1
            textRead.ReadLine()
            text(i, 0) = textRead.ReadLine() 'chinese textbox2
            text(i, 1) = textRead.ReadLine() 'english textbox3
            textRead.ReadLine()
        Next
        For i = 0 To textline - 1
            If text(i, 0) = TextBox2.Text And text(i, 1) = TextBox3.Text Then
                textfind = True
                textnum = i
            ElseIf textline - 1 = i And textfind = False Then
                MsgBox("並未找到該題，請確認是否輸入正確！", MsgBoxStyle.Exclamation, "System")
                textRead.Close()
                GoTo endsub
            End If
        Next
        '刪除題目-----
        If textnum <> textline - 1 Then
            While textfind = True
                If textnum <> textline - 1 Then
                    text(textnum, 0) = text(textnum + 1, 0)
                    text(textnum, 1) = text(textnum + 1, 1)
                    textnum += 1
                Else
                    textfind = False
                End If
            End While
        End If
        textline -= 1
        textRead.Close()
        My.Computer.FileSystem.DeleteFile(Label4.Text)
        '重新寫入-----
        Dim textWriter As StreamWriter = My.Computer.FileSystem.OpenTextFileWriter(Label4.Text, True)
        textWriter.WriteLine("EnglishReadUSE")
        textWriter.WriteLine(textline)
        If textline <> 0 Then
            If textline <> 1 Then
                For i = 0 To textline - 2
                    textWriter.WriteLine(i + 1)
                    textWriter.WriteLine(text(i, 0))
                    textWriter.WriteLine(text(i, 1))
                    textWriter.WriteLine()
                Next
                textWriter.WriteLine(textline)
                textWriter.WriteLine(text(textline - 1, 0))
                textWriter.WriteLine(text(textline - 1, 1))
            Else
                textWriter.WriteLine(1)
                textWriter.WriteLine(text(0, 0))
                textWriter.WriteLine(text(0, 1))
            End If
        End If
        textWriter.Flush() : textWriter.Close()
        '寫入至Textbox1-----
        Dim aftertext As StreamReader = My.Computer.FileSystem.OpenTextFileReader(Label4.Text)
        aftertext.ReadLine()
        aftertext.ReadLine()
        TextBox1.Text = aftertext.ReadToEnd
        aftertext.Close()
        '初始化-----
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox2.Focus()
endsub: End Sub
    '/新增題庫/
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim FolderBrowserDialog1 As FolderBrowserDialog = New FolderBrowserDialog
        If FolderBrowserDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
            If My.Computer.FileSystem.FileExists(FolderBrowserDialog1.SelectedPath & "\EnglishRead.txt") = True Then
                MsgBox("檔案已存在(檔名:EnglishRead)" & vbCrLf & FolderBrowserDialog1.SelectedPath & "\EnglishRead.txt", MsgBoxStyle.Critical, "System")
            Else
                Dim textWriter As StreamWriter = My.Computer.FileSystem.OpenTextFileWriter(FolderBrowserDialog1.SelectedPath & "\EnglishRead.txt", True)
                textWriter.WriteLine("EnglishReadUSE")
                textWriter.WriteLine("0")
                textWriter.Flush() : textWriter.Close()
            End If
        End If
    End Sub
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox2.Focus()
        TextBox2.Enabled = False
        TextBox3.Enabled = False
        TextBox1.Enabled = False
    End Sub
    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        If e.KeyChar = Chr(10) Or e.KeyChar = Chr(13) Then
            TextBox3.Focus()        'Ctri+Enter
        End If
    End Sub
    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        If e.KeyChar = Chr(13) Then 'Enter
            Button2.PerformClick()  '按鈕click事件
        ElseIf e.KeyChar = Chr(10) Then
            TextBox2.Focus()        'Ctri+Enter
        End If
    End Sub

    Private Sub Form2_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        If MsgBox("是否確定關閉程式", MsgBoxStyle.OkCancel, "System") = 1 Then
            End
        End If
    End Sub
End Class