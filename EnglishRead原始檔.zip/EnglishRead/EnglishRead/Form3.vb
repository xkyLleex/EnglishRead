﻿Public Class Form3
    '/START/
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Debug-----
        If Label4.Text = "" Then
            MsgBox("請選擇題庫或新增題庫", MsgBoxStyle.Information, "System")
            GoTo endsub
        End If
        Dim linetext As String
        Dim textline As Integer     '題數
        Dim textRead As IO.StreamReader = My.Computer.FileSystem.OpenTextFileReader(Label4.Text)
        If textRead.ReadLine() = "EnglishReadUSE" Then
            linetext = textRead.ReadLine()
            If Integer.TryParse(linetext, textline) = False Then
                MsgBox("檔案資料型態錯誤，建議重新建立資料", MsgBoxStyle.Critical, "System")
                textRead.Close()
                GoTo endsub
            End If
        Else
            MsgBox("檔案資料型態錯誤，建議重新建立資料", MsgBoxStyle.Critical, "System")
            textRead.Close()
            GoTo endsub
        End If
        If textline = 0 Then
            MsgBox("只有0題是要考啥?", MsgBoxStyle.Critical, "System")
            GoTo endsub
        End If
        Button2.Enabled = False : ToolStripButton1.Enabled = False : ToolStripButton2.Enabled = False : ToolStripButton3.Enabled = False
        '總題數-----
        Label1.Text = textline & "題"
        '隨機題目運算-----
        Dim text(textline, 1), ans As String
        Dim random, random01 As New Random()
        Dim textturn As Boolean = True
        Dim n, ran As Integer
        For i = 0 To textline - 1
            textRead.ReadLine()
            text(i, 0) = textRead.ReadLine() 'chinese
            text(i, 1) = textRead.ReadLine() 'english
            textRead.ReadLine()
        Next
        For n = 0 To textline - 1
            ran = random.Next(0, textline - n)
            If random01.Next(0, 2) = 0 Then     '0 or 1
                ans = InputBox(text(ran, 0) & "的英文是?", "System", "")
                If text(ran, 1) <> ans Then
                    MsgBox(text(ran, 0) & "的英文是" & text(ran, 1), MsgBoxStyle.OkOnly, "System")
                    GoTo endtest
                End If
            Else
                ans = InputBox(text(ran, 1) & "的中文是?", "System", "")
                If text(ran, 0) <> ans Then
                    MsgBox(text(ran, 1) & "的中文是" & text(ran, 0), MsgBoxStyle.OkOnly, "System")
                    GoTo endtest
                End If
            End If
            While textturn = True
                If ran <> textline - 1 Then
                    text(ran, 0) = text(ran + 1, 0)
                    text(ran, 1) = text(ran + 1, 1)
                    ran += 1
                Else
                    textturn = False
                End If
            End While
            textturn = True
        Next
        '結束運算並結算-----
        MsgBox("恭喜答對題庫裡所有答案", MsgBoxStyle.OkOnly, "System")
endtest: Label6.Text = n & "題"
        Button2.Enabled = True : ToolStripButton1.Enabled = True : ToolStripButton2.Enabled = True : ToolStripButton3.Enabled = True
        textRead.Close()
endsub: End Sub
    'READ
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim OpenFileDialog1 As OpenFileDialog = New OpenFileDialog
        OpenFileDialog1.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.Desktop
        OpenFileDialog1.Filter = "txt files (*.txt)|*.txt"
        If (OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            Dim text As IO.StreamReader = My.Computer.FileSystem.OpenTextFileReader(OpenFileDialog1.FileName)
            If text.ReadLine() = "EnglishReadUSE" Then
                If Integer.TryParse(text.ReadLine(), Nothing) = False Then
                    MsgBox("檔案資料型態錯誤", MsgBoxStyle.Critical, "System")
                    text.Close()
                    GoTo endsub
                End If
            Else
                MsgBox("檔案資料型態錯誤", MsgBoxStyle.Critical, "System")
                text.Close()
                GoTo endsub
            End If
            Label4.Text = OpenFileDialog1.FileName
            Button1.Enabled = True
endsub:     text.Close()
        End If
    End Sub
    '-------------------------------------------------------------------------------------------------------------------
    Private Sub ToolStripButton2_Click(sender As Object, e As EventArgs) Handles ToolStripButton2.Click
        Form2.Show()
        Me.Hide()
    End Sub

    Private Sub ToolStripButton3_Click(sender As Object, e As EventArgs) Handles ToolStripButton3.Click
        Form4.Show()
        Me.Hide()
    End Sub
    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click
        Form1.Show()
        Me.Hide()
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Button1.Enabled = False
    End Sub

    Private Sub Form3_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        If MsgBox("是否確定關閉程式", MsgBoxStyle.OkCancel, "System") = 1 Then
            End
        End If
    End Sub
End Class