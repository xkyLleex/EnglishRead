﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [chinese] NVARCHAR(50) NULL, 
    [english] NVARCHAR(50) NULL
)
